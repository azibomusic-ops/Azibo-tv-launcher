package com.bilona.tv;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int coffee = Color.rgb( forty(), 27, 19);
    private final int card = Color.rgb(191, 151, 108);
    private final int cream = Color.rgb(247, 231, 207);
    private final int dark = Color.rgb(57, 37, 26);

    private static int forty() { return 40; }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildScreen();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); d.setStroke(2, Color.argb(35,255,255,255)); return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(42, 24, 42, 28); root.setBackgroundColor(coffee);
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setOrientation(LinearLayout.HORIZONTAL);
        TextView brand = text("BILONA", 38, cream, true); top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView date = text(new SimpleDateFormat("EEE, d MMM  •  HH:mm", Locale.getDefault()).format(new Date()), 17, Color.rgb(220,194,164), false); top.addView(date);
        root.addView(top);
        TextView subtitle = text("TV  •  MOVIES  •  ENTERTAINMENT", 12, Color.rgb(201,155,104), true); subtitle.setLetterSpacing(0.16f); subtitle.setPadding(3, 2, 0, 22); root.addView(subtitle);
        View line = new View(this); line.setBackgroundColor(Color.rgb(105,75,53)); root.addView(line, new LinearLayout.LayoutParams(-1, 1));
        TextView heading = text("Ilovalar", 20, cream, true); heading.setPadding(2, 18, 0, 12); root.addView(heading);
        ScrollView scroll = new ScrollView(this); GridLayout grid = new GridLayout(this); grid.setColumnCount(5); grid.setUseDefaultMargins(false); grid.setPadding(0, 4, 0, 8);
        List<ResolveInfo> apps = new ArrayList<>();
        Intent query = new Intent(Intent.ACTION_MAIN); query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        for (ResolveInfo ri : pm.queryIntentActivities(query, 0)) {
            if (!getPackageName().equals(ri.activityInfo.packageName)) apps.add(ri);
        }
        Collections.sort(apps, new Comparator<ResolveInfo>() { public int compare(ResolveInfo a, ResolveInfo b) { return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()); }});
        for (ResolveInfo app : apps) {
            LinearLayout tile = new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.CENTER); tile.setPadding(8, 14, 8, 12); tile.setBackground(shape(card, 20)); tile.setFocusable(true); tile.setFocusableInTouchMode(true);
            ImageView icon = new ImageView(this); try { icon.setImageDrawable(app.loadIcon(pm)); } catch (Exception ignored) {}
            tile.addView(icon, new LinearLayout.LayoutParams(58, 58));
            TextView name = text(app.loadLabel(pm).toString(), 15, dark, true); name.setGravity(Gravity.CENTER); name.setMaxLines(2); name.setPadding(0, 8, 0, 0); tile.addView(name);
            tile.setOnClickListener(v -> { Intent launch = pm.getLaunchIntentForPackage(app.activityInfo.packageName); if (launch != null) startActivity(launch); });
            tile.setOnFocusChangeListener((v, focused) -> { v.setScaleX(focused ? 1.08f : 1f); v.setScaleY(focused ? 1.08f : 1f); v.setBackground(shape(focused ? cream : card, 20)); });
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams(); lp.width = 0; lp.height = 132; lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); lp.setMargins(7, 7, 7, 7); grid.addView(tile, lp);
        }
        if (apps.isEmpty()) { TextView empty = text("Hozircha ochiladigan ilovalar topilmadi", 18, cream, false); grid.addView(empty); }
        scroll.addView(grid); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView footer = text("BILONA TV  •  Qulay tomosha qiling", 12, Color.rgb(184,151,119), false); footer.setGravity(Gravity.CENTER); footer.setPadding(0, 12, 0, 0); root.addView(footer);
        setContentView(root);
        if (grid.getChildCount() > 0) grid.getChildAt(0).requestFocus();
    }
}

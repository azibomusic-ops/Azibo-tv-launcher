# BILONA TV Launcher

Coffee-and-kraft themed Android TV launcher with installed app icons, remote focus navigation, and app launching.

## Build
GitHub Actions workflow: `.github/workflows/build.yml`. Run it from Actions using **Run workflow**. Download the `BILONA-TV-APK` artifact and extract `app-debug.apk`.

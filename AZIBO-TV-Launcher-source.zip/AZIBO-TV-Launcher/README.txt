AZIBO TV Launcher - source project

This is an Android Studio/Gradle project. It is not a compiled APK.

Build:
  gradle assembleDebug

Output:
  app/build/outputs/apk/debug/app-debug.apk

GitHub Actions:
  Upload this project to a GitHub repository, then open Actions > Build AZIBO TV APK > Run workflow.
  Download the AZIBO-TV-Launcher-APK artifact and extract app-debug.apk.

Notes:
- The app lists launchable apps and can be selected as a HOME app if the TV firmware permits it.
- It does not remove Sber system ads or replace protected system components.
- Actual compatibility must be tested on the target SberOS firmware.

package uz.azibo.tvlauncher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(9,11,18)); getWindow().setNavigationBarColor(Color.rgb(9,11,18)); build(); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void build() {
        int white=Color.WHITE, muted=Color.rgb(166,174,190), gold=Color.rgb(245,197,66);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(42),dp(28),dp(42),dp(24)); root.setBackgroundColor(Color.rgb(9,11,18));
        TextView brand=text("AZIBO",30,white,true); root.addView(brand);
        TextView sub=text("TV  ·  SODDA. TEZ. QULAY.",12,muted,true); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-2,-2); sp.topMargin=dp(3); root.addView(sub,sp);
        TextView heading=text("Ilovalaringiz",21,white,true); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-2,-2); hp.topMargin=dp(30); hp.bottomMargin=dp(14); root.addView(heading,hp);
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); scroll.addView(list); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        Intent query=new Intent(Intent.ACTION_MAIN); query.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        PackageManager pm=getPackageManager(); List<ResolveInfo> apps=pm.queryIntentActivities(query,0);
        if (apps.isEmpty()) { query.removeCategory(Intent.CATEGORY_LEANBACK_LAUNCHER); query.addCategory(Intent.CATEGORY_LAUNCHER); apps=pm.queryIntentActivities(query,0); }
        final List<ResolveInfo> finalApps=new ArrayList<>(); for(ResolveInfo r:apps) if(!r.activityInfo.packageName.equals(getPackageName())) finalApps.add(r);
        Collections.sort(finalApps,new Comparator<ResolveInfo>() { public int compare(ResolveInfo a,ResolveInfo b){ return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()); }});
        int columns=4; LinearLayout row=null;
        for(int i=0;i<finalApps.size();i++) {
            if(i%columns==0){ row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2); rp.bottomMargin=dp(12); list.addView(row,rp); }
            final ResolveInfo info=finalApps.get(i);
            LinearLayout tile=new LinearLayout(this); tile.setOrientation(LinearLayout.VERTICAL); tile.setGravity(Gravity.CENTER); tile.setPadding(dp(8),dp(14),dp(8),dp(14)); tile.setBackground(bg(Color.rgb(25,30,43),16)); tile.setFocusable(true); tile.setFocusableInTouchMode(true);
            TextView icon=text("●",28,gold,true); icon.setGravity(Gravity.CENTER); tile.addView(icon);
            TextView name=text(info.loadLabel(pm).toString(),14,white,true); name.setGravity(Gravity.CENTER); name.setMaxLines(2); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2); np.topMargin=dp(8); tile.addView(name,np);
            tile.setOnClickListener(v->{ Intent launch=pm.getLaunchIntentForPackage(info.activityInfo.packageName); if(launch!=null) startActivity(launch); });
            tile.setOnFocusChangeListener((v,focused)->v.setBackground(bg(focused?Color.rgb(62,54,31):Color.rgb(25,30,43),16)));
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(112),1); tp.setMargins(dp(5),0,dp(5),0); row.addView(tile,tp);
        }
        if(finalApps.isEmpty()){ TextView empty=text("Hozircha TV ilovalari topilmadi.",16,muted,false); list.addView(empty); }
        TextView foot=text("Pult bilan tanlang  •  Ilovani ochish uchun OK bosing",12,muted,false); LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-2,-2); fp.topMargin=dp(12); root.addView(foot,fp);
        setContentView(root); if(row!=null && row.getChildCount()>0) row.getChildAt(0).requestFocus();
    }
}
